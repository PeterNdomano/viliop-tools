## Meta Scrapper
This tool collects all posible metadata and metafiles for the given web url target.
Meta files will be stored as is but meta data will be saved in a file(name to be given later)

### Algorithm Summary
1) Checks for common metadata files like robots.txt etc....
2) Then checks for meta-data found in html tags and other sources inside the target
